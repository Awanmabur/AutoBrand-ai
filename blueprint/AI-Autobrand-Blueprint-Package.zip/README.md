# AI Autobrand Blueprint Package

This package expands the original ODT blueprint into a build-ready plan.

Files:

- `AI-Autobrand-Expanded-Blueprint.md`: full product blueprint.
- `Implementation-Roadmap.md`: phased build plan and day estimates.
- `Data-Models.md`: database model outline.
- `.env.example`: environment variables for the planned stack.

Key changes added:

- JWT auth instead of session auth.
- Clean AI video generation.
- Image upload to AI workflows.
- Upload-your-image clone/avatar video generation.
- Consent and safety rules for avatar/clone media.
- Video provider abstraction.
- Credit and usage system for expensive features.
- Clearer MVP and premium feature split.
